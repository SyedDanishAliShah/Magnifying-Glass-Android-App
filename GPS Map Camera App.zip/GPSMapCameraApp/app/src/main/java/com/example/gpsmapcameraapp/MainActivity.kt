package com.example.gpsmapcameraapp

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.TorchState
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.airbnb.lottie.LottieAnimationView
import com.example.gpsmapcameraapp.focusview.FocusView
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private val PERMISSION_REQUEST_CODE = 100
    private lateinit var flashLightIcon: ImageView
    private lateinit var cameraIcon: ImageView
    private var isBackCameraSelected = true // Flag to track the currently selected camera
    private lateinit var optionsIcon: ImageView
    private lateinit var cardView: CardView
    private var isOptionsIconSelected = false
    private lateinit var timerIcon: ImageView
    private lateinit var imageCaptureIcon: ImageView
    private var imageCapture: ImageCapture? = null
    private lateinit var collectionIcon: ImageView
    private lateinit var progressBarAnimation: LottieAnimationView
    private lateinit var threeToOneAnimationView: LottieAnimationView
    private lateinit var fiveToOneAnimationView: LottieAnimationView
    private lateinit var timerTv: TextView
    private lateinit var cityCountryTv: TextView
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var longLatTv: TextView
    private lateinit var cardViewGoogleMap: CardView
    private lateinit var soundOffIcon : ImageView
    private lateinit var soundOffTv : TextView
    private var isSoundOn = true
    private lateinit var focusManualIcon : ImageView
    private var isFocusManual = true
    private lateinit var focusView: FocusView
    private lateinit var focusTv : TextView
    private lateinit var focusAutoTv :TextView
    private val handler = Handler()
    private var isFirstClick = true
    private lateinit var whiteBalanceIcon : ImageView



    @SuppressLint("SetTextI18n", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        flashLightIcon = findViewById(R.id.flash_light_icon_main_activity)
        cameraIcon = findViewById(R.id.camera_change_icon_main_activity)
        optionsIcon = findViewById(R.id.options_icon_main_activity)
        cardView = findViewById(R.id.card_view_options_icon)
        timerIcon = findViewById(R.id.timer_off_icon)
        imageCaptureIcon = findViewById(R.id.image_capture_icon)
        collectionIcon = findViewById(R.id.collection_icon)
        progressBarAnimation = findViewById(R.id.progress_bar_animation)
        timerTv = findViewById(R.id.timer_off_tv)
        threeToOneAnimationView = findViewById(R.id.three_to_one_animation_view)
        fiveToOneAnimationView = findViewById(R.id.five_to_one_animation_view)
        cityCountryTv = findViewById(R.id.city_country_tv)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        longLatTv = findViewById(R.id.long_lat_tv)
        cardViewGoogleMap = findViewById(R.id.map_card_view)
        soundOffIcon = findViewById(R.id.sound_off_icon)
        soundOffTv = findViewById(R.id.sound_off_tv)
        focusManualIcon = findViewById(R.id.focus_manual_icon)
        focusView = findViewById(R.id.focusView)
        focusTv = findViewById(R.id.focus_manual_tv)
        focusAutoTv = findViewById(R.id.focus_auto_tv)
        whiteBalanceIcon = findViewById(R.id.white_balance_icon)

        whiteBalanceIcon.setOnClickListener {

        }

        // Set the focus icon initially invisible
        // Set the focus icon initially invisible
        focusView.visibility = View.INVISIBLE

        // Track the last click time for auto focus
        System.currentTimeMillis()

        // Modify your onTouchListener to call this function when ACTION_DOWN is detected
        previewView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (isFocusManual) {
                        focusView.x = event.x - focusView.width / 2
                        focusView.y = event.y - focusView.height / 2
                        showFocusIconFor3Seconds()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    // Hide the focus icon when touch is released
                    focusView.visibility = View.INVISIBLE
                }
            }
            true // Consume the touch event
        }

        // Start a timer to show the focus icon every 8 seconds
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (!isFocusManual) {
                    focusView.visibility = View.VISIBLE
                    // Add any zoom in and out animation here if needed
                    handler.postDelayed({
                        focusView.visibility = View.INVISIBLE
                    }, 3000) // Hide the focus icon after 3 seconds
                }

                // Repeat the timer every 8 seconds
                handler.postDelayed(this, 8000)
            }
        }, 8000) // Start the timer after 8 seconds

        focusManualIcon.setOnClickListener {
            isFocusManual = !isFocusManual
            if (isFocusManual) {
                isFirstClick = true
                focusManualIcon.setImageResource(R.drawable.focus_manual_icon)
                focusView.setFocusShape(FocusView.FOCUS_SHAPE_SQUARE)
                focusTv.visibility = View.VISIBLE
                focusAutoTv.visibility = View.INVISIBLE
                focusView.setManualFocus(true)
                // Show the focus icon for 3 seconds if in manual focus mode
                showFocusIconFor3Seconds()
            } else {
                focusView.visibility = View.VISIBLE
                isFirstClick = true
                focusManualIcon.setImageResource(R.drawable.focus_auto)
                focusView.setFocusShape(FocusView.FOCUS_SHAPE_CIRCLE)
                focusTv.visibility = View.INVISIBLE
                focusAutoTv.visibility = View.VISIBLE
                focusView.setManualFocus(false)
            }
        }
        restoreSoundState()

        soundOffIcon.setOnClickListener {
            isSoundOn = !isSoundOn
            if (isSoundOn) {
                soundOffIcon.setImageResource(R.drawable.sound_on_icon)
                soundOffTv.text = "Sound On"
            } else {
                soundOffIcon.setImageResource(R.drawable.sound_off_icon)
                soundOffTv.text = "Sound Off"
            }
            // Save the sound state
            saveSoundState(isSoundOn)
        }

        val capturedByTv = findViewById<TextView>(R.id.captured_by_tv)
        // Set the text
        capturedByTv.text = "Captured by : GPS Map Camera App"

        // Request location updates
        requestLocationUpdates()

        val rootLayout =
            findViewById<View>(R.id.root_layout_activity_main) // Assuming 'root_layout' is the ID of your root layout
        rootLayout.setOnClickListener {
            if (!isOptionsIconSelected) {
                optionsIcon.setImageResource(R.drawable.options_icon_main_activity)
                cardView.visibility = View.INVISIBLE
            }
            isOptionsIconSelected = false
        }

        collectionIcon.setOnClickListener {
            val intent = Intent().apply {
                action = Intent.ACTION_VIEW
                type = "image/*"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        }

        flashLightIcon.setOnClickListener {
            toggleFlashlight()
        }

        imageCaptureIcon.setOnClickListener {
            // Check if the timer is set to 3 seconds
            when (timerTv.text) {
                "Timer 3sec" -> {
                    threeToOneAnimationView.visibility = View.VISIBLE
                    threeToOneAnimationView.playAnimation()
                    threeToOneAnimationView.addAnimatorListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            // Stop the animation
                            threeToOneAnimationView.clearAnimation()
                            // Play the sound of the camera if sound is on
                            if (isSoundOn) {
                                playCameraSound()
                            }
                            // Capture the image after stopping the animation
                            captureImage()

                        }
                    })
                }
                // Check if the timer is set to 5 seconds
                "Timer 5sec" -> {
                    fiveToOneAnimationView.visibility = View.VISIBLE
                    fiveToOneAnimationView.playAnimation()
                    fiveToOneAnimationView.addAnimatorListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            // Stop the animation
                            fiveToOneAnimationView.clearAnimation()
                            // Play the sound of the camera if sound is on
                            if (isSoundOn) {
                                playCameraSound()
                            }
                            // Capture the image after stopping the animation
                            captureImage()

                        }
                    })
                }
                else -> {
                    // Play the sound of the camera if sound is on
                    if (isSoundOn) {
                        playCameraSound()
                    }
                    // Timer is off, capture the image immediately
                    captureImage()
                }
            }
        }
        var clickCount = 0

        timerIcon.setOnClickListener {
            clickCount++
            when (clickCount % 3) {
                1 -> {
                    timerIcon.setImageResource(R.drawable.selected_timer_icon)
                    timerTv.text = "Timer 3sec"
                    saveTimerState("Timer 3sec", R.drawable.selected_timer_icon)
                }

                2 -> {
                    timerIcon.setImageResource(R.drawable.selected_timer_icon)
                    timerTv.text = "Timer 5sec"
                    saveTimerState("Timer 5sec", R.drawable.selected_timer_icon)
                }

                else -> {
                    timerIcon.setImageResource(R.drawable.timer_off_icon)
                    timerTv.text = "Timer Off"
                    saveTimerState("Timer Off", R.drawable.timer_off_icon)
                }
            }
        }


        optionsIcon.setOnClickListener {
            if (!isOptionsIconSelected) {
                optionsIcon.setImageResource(R.drawable.options_selected_icon)
                cardView.visibility = View.VISIBLE

            } else {
                optionsIcon.setImageResource(R.drawable.options_icon_main_activity)
                cardView.visibility = View.INVISIBLE
            }
            isOptionsIconSelected = !isOptionsIconSelected

        }


        val permissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        // Check if all permissions are granted
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        )
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE)
        else {
            // Permissions already granted. Use the camera and location as needed.
        }
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            var cameraPermissionGranted = false
            var locationPermissionGranted = false

            for (i in permissions.indices) {
                if (permissions[i] == Manifest.permission.CAMERA && grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    cameraPermissionGranted = true
                }
                if ((permissions[i] == Manifest.permission.ACCESS_FINE_LOCATION || permissions[i] == Manifest.permission.ACCESS_COARSE_LOCATION) && grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    locationPermissionGranted = true
                }
            }

            if (cameraPermissionGranted && locationPermissionGranted) {
                startCamera()
                requestLocationUpdates()
                Toast.makeText(this, "Permissions Granted", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Permissions Denied", Toast.LENGTH_LONG).show()
            }
        }
    }


    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            // Used to bind the lifecycle of cameras to the lifecycle owner
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // Preview
            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder().build()

            // Select back camera as a default
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                // Unbind use cases before rebinding
                cameraProvider.unbindAll()

                // Bind use cases to camera
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)

                flashLightIcon.setOnClickListener {
                    val camera = cameraProvider.bindToLifecycle(this, cameraSelector)

                    if (camera.cameraInfo.hasFlashUnit()) {
                        val cameraControl = camera.cameraControl
                        val torchState = camera.cameraInfo.torchState.value
                        val isTorchOn = torchState == TorchState.ON

                        // Check if the back camera is selected before changing the icon
                        if (isBackCameraSelected) {
                            if (isTorchOn) {
                                flashLightIcon.setImageResource(R.drawable.flash_light_icon_main_activity)
                            } else {
                                flashLightIcon.setImageResource(R.drawable.flash_on_icon)
                            }

                            cameraControl.enableTorch(!isTorchOn)
                        }
                    }
                }

                cameraIcon.setOnClickListener {
                    val newCameraSelector = if (isBackCameraSelected) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }

                    try {
                        // Unbind all use cases before rebinding with the new camera selector
                        cameraProvider.unbindAll()

                        // Bind use cases to camera with the new camera selector
                        cameraProvider.bindToLifecycle(
                            this,
                            newCameraSelector,
                            preview,
                            imageCapture
                        )

                        if (!isBackCameraSelected) {
                            flashLightIcon.setImageResource(R.drawable.flash_light_icon_main_activity)
                        } else {
                            flashLightIcon.setImageResource(R.drawable.flash_light_icon_main_activity)
                        }

                        isBackCameraSelected =
                            !isBackCameraSelected // Toggle the camera selection flag

                        // Update the camera icon based on the selected camera
                        cameraIcon.setImageResource(if (isBackCameraSelected) R.drawable.camera_change_icon_main_activity else R.drawable.front_cam_icon)
                    } catch (exc: Exception) {
                        Log.e(TAG, "Use case binding failed", exc)
                    }
                }

            } catch (exc: Exception) {
                Log.e(TAG, "Use case binding failed", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }


    @SuppressLint("SetTextI18n")
    private fun requestLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            return
        }
        fusedLocationClient.lastLocation
                .addOnSuccessListener { location: Location? ->
                    // Got last known location. In some rare situations this can be null.
                    location?.let {
                        // Get city, province, and country from the location
                        val address = getAddress(location.latitude, location.longitude)
                        val city = address.locality
                        val province = address.adminArea // Province
                        val country = address.countryName
                        // Update the TextViews with the location information
                        findViewById<TextView>(R.id.city_country_tv).text = "$city, $province, $country"
                        findViewById<TextView>(R.id.long_lat_tv).text = "Latitude: ${location.latitude}, Longitude: ${location.longitude}"

                        // Get current date, day, and time
                        val currentDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                        val currentDay = SimpleDateFormat("EEEE", Locale.getDefault()).format(Date())
                        val currentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                        // Update the date, day, and time TextView
                        findViewById<TextView>(R.id.date_day_time_tv).text = "$currentDate, $currentDay, $currentTime"
                    }
                    val mapFragment = supportFragmentManager.findFragmentById(R.id.map_fragment) as SupportMapFragment
                    mapFragment.getMapAsync { googleMap ->
                        // Add a marker at the current location and move the camera
                        val latLng = location?.let { LatLng(it.latitude, location.longitude) }
                        latLng?.let { MarkerOptions().position(it).title("Marker") }
                            ?.let { googleMap.addMarker(it) }
                        latLng?.let { CameraUpdateFactory.newLatLngZoom(it, 15f) }
                            ?.let { googleMap.moveCamera(it) }
                    }
                }
    }

    private fun getAddress(latitude: Double, longitude: Double): Address {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses: List<Address> = geocoder.getFromLocation(latitude, longitude, 1)!!
        return addresses[0]
    }


    override fun onStart() {
        super.onStart()
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        }

    }

    private fun toggleFlashlight() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
        val camera = cameraProvider.bindToLifecycle(this, cameraSelector)
        if (camera.cameraInfo.hasFlashUnit()) {
            val cameraControl = camera.cameraControl
            val torchState = camera.cameraInfo.torchState.value
            val isTorchOn = torchState == TorchState.ON

            // Check if the back camera is selected before changing the icon
            if (!isBackCameraSelected) {
                cameraControl.enableTorch(!isTorchOn)
                flashLightIcon.setImageResource(R.drawable.flash_light_icon_main_activity)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        cameraIcon.setImageResource(R.drawable.camera_change_icon_main_activity)
        flashLightIcon.setImageResource(R.drawable.flash_light_icon_main_activity)
        restoreTimerState()
        val availability = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this)
        if (availability != ConnectionResult.SUCCESS) {
            GoogleApiAvailability.getInstance().getErrorDialog(this, availability, 0)?.show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    private fun captureImage() {

        val imageCapture = imageCapture ?: return

        // Create a file to save the captured image
        val photoFile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "IMG_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        )


        // Create output options object which contains file + metadata
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        if (timerTv.text != "Timer 3sec" && timerTv.text != "Timer 5sec") {
            progressBarAnimation.visibility = View.VISIBLE
            progressBarAnimation.playAnimation()
        }

        // Capture the image and save it to the specified file
        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val savedUri = outputFileResults.savedUri ?: Uri.fromFile(photoFile)

                    progressBarAnimation.visibility = View.INVISIBLE
                    threeToOneAnimationView.visibility = View.INVISIBLE
                    fiveToOneAnimationView.visibility = View.INVISIBLE
                    // Display a message indicating that the image has been saved to the gallery
                    Toast.makeText(this@MainActivity, "Image saved to gallery", Toast.LENGTH_SHORT)
                        .show()

                    // Broadcast the saved image to the media scanner so it is immediately available in the gallery
                    val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                    mediaScanIntent.data = savedUri
                    sendBroadcast(mediaScanIntent)
                }

                override fun onError(exception: ImageCaptureException) {

                    progressBarAnimation.visibility = View.INVISIBLE
                    threeToOneAnimationView.visibility = View.INVISIBLE
                    fiveToOneAnimationView.visibility = View.INVISIBLE
                    // Image capture failed, handle error
                    Log.e(TAG, "Image capture failed: ${exception.message}", exception)
                    Toast.makeText(this@MainActivity, "Failed to save image", Toast.LENGTH_SHORT)
                        .show()
                }
            })
    }

    private fun saveTimerState(timerState: String, iconResId: Int) {
        val sharedPref = getSharedPreferences("timer_state", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putString("timer_state_key", timerState)
            putInt("timer_icon_key", iconResId)
            apply()
        }
    }

    private fun restoreTimerState() {
        val sharedPref = getSharedPreferences("timer_state", Context.MODE_PRIVATE)
        val timerState = sharedPref.getString("timer_state_key", "Timer Off")
        val iconResId = sharedPref.getInt("timer_icon_key", R.drawable.timer_off_icon)
        timerIcon.setImageResource(iconResId)
        timerTv.text = timerState
    }

    private fun playCameraSound() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.camera_shutter_6305)
        mediaPlayer?.start()
    }
    private fun saveSoundState(isSoundOn: Boolean) {
        val sharedPref = getSharedPreferences("sound_state", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putBoolean("is_sound_on", isSoundOn)
            apply()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun restoreSoundState() {
        val sharedPref = getSharedPreferences("sound_state", Context.MODE_PRIVATE)
        isSoundOn = sharedPref.getBoolean("is_sound_on", true)
        if (isSoundOn) {
            soundOffIcon.setImageResource(R.drawable.sound_on_icon)
            soundOffTv.text = "Sound On"
        } else {
            soundOffIcon.setImageResource(R.drawable.sound_off_icon)
            soundOffTv.text = "Sound Off"
        }
    }

    private fun showFocusIconFor3Seconds() {
        focusView.visibility = View.VISIBLE
        handler.postDelayed({
            focusView.visibility = View.INVISIBLE
        }, 3000) // 3000 milliseconds = 3 seconds
    }


}